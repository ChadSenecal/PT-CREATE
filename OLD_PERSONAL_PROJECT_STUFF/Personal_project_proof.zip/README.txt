-This is the final outcome and proof of my progression in the personal project.

-The file labled "PersonalProject" is the actual IDE generated file for this project.
	-Inside of that file you will find my code, and resouces that I had made.Some of which I didn't use.
	-Inside of the Resource file is all my img resources I used in the project.
	-Inside of the src file is a list of more files that contain the code to my project, with the main file being the main entry point.
	-All other files not in the file category listed are IDE generated files not touched by me.

-The file labled "Personal project photos videos" is the file I keep most of resources, videos, and plans that I had made in the project.
	-This file is very straight forward and doesn't require digging.